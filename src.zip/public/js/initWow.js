if (typeof WOW !== 'undefined') {
  new WOW().init();
}